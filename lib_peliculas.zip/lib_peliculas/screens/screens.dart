export 'package:peliculas/screens/details_screen.dart';
export 'package:peliculas/screens/home_screen.dart';
