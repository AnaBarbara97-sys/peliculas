import 'package:flutter/material.dart';
import 'package:peliculas/providers/menu_provider.dart';
import 'package:peliculas/widgets/movie_slider_top_rated.dart';
import 'package:peliculas/widgets/movie_slider_upcoming.dart';
import 'package:peliculas/widgets/widgets.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final movieProvider = Provider.of<MoviesProvider>(context);
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.pinkAccent,
          title: const Text('Películas'),
          elevation: 0,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              CardSwiper(pelis: movieProvider.onDisplayMovie),
              MovieSlider(populares: movieProvider.onPopularMovie),
              MovieSliderTopRated(valorados: movieProvider.onTopRatedMovie),
              MovieSliderUpcoming(estrenos: movieProvider.onUpcomingMovie),
            ],
          ),
        ));
  }
}
